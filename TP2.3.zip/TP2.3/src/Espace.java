import java.io.FileNotFoundException;
import java.io.IOException;

/***************************************************************
 * Auteur : No�mie St-Onge et �douard Laforge
 *
 * Description : Classe qui repr�sente l'espace. Elle contient
 * le satellite et sert d'interm�diaire entre la lune et la 
 * Terre.
 ***************************************************************/

public class Espace {

	/*
	 * Attributs
	 */

	private Robot robot;

	private Satellite satellite;


	
	/*
	 * Constructeur par copie d'attributs
	 */

	public Espace(Robot robot, Satellite satellite) {
		
		this.robot = robot ;
		this.satellite = satellite; 
		
	}
	


	/*
	 * Accesseur
	 */

	public Paquet getPaquet() {
		return this.satellite.getPaquet();
	}



	/** Auteur : Noemie St-Onge
	 * Mutateur du paquet
	 * @param paquet paquet qui sera chang� 
	 */
	
	public void setPaquet(Paquet paquet) throws IOException, 
		FileNotFoundException {
		
		// envoie le paquet au satellite
		satellite.setPaquet(paquet);
		
		// fait avancer le satellite
		satellite.deplacerSatellite();
	
		// envoie l'image du satellite au robot
		robot.setImage(satellite.getImage());
		
	 
		// envoie le paquet du robot au satellite
		satellite.setPaquet(robot.getPaquet());
	} 
}
