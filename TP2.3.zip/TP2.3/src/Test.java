
public class Test {
	
	//TEST SATELITTE 
	
	/*
	 * Auteur : Edouard Laforge
	 */
	public static void testConstructeurSatellite() {
		
		/*
		 * Strategie : Pour tester le constructeur, nous allons simplement cr�er
		 * une instance de Satellite et voir si les attributs sont bons avec la
		 * m�thode toString qui retourne un string contenant tous les attributs 
		 * et leur valeur 
		 */
		
		Satellite s = new Satellite();
		
		//On cr�� un String que l'on affiche par la suite sur la console 
		
		String x = s.toString();
		
		System.out.println(x); 
		
	}
	
	/*
	 * Auteur : Edouard Laforge
	 */
	public static void testGetImage() {
		/*
		 * Strategie : Nous allons cr�er un satellite par d�faut et ensuite nous 
		 * allons tester getImage en faisant appel � la fonction. On va par la 
		 * suite afficher le resultat sur la console (devrait �tre null)
		 */
		
		Satellite s = new Satellite(); 
		
		String x = s.getImage().nomFichier; 
		
		System.out.println(x);
		
	}
	
	/*
	 * Auteur : Edouard Laforge 
	 */
	
	public static void testGetPaquet() {
		
		/*
		 * Strategie : On cr�e un nouveau paquet que l'on envoit au Satellite avec
		 * setPaquet (type DATA). On change aussi le nom pour pouvoir identifier le Paquet.
		 * Par la suite on utilise la fonction � tester (getPaquet) pour aller chercher le 
		 * nom du paquet inserer dans Satellite.
		 */
		
		Paquet p = new Paquet(); 
		
		p.setNomFichier("Allo");
		
		p.setTypePaquet(Constantes.DATA);
		
		Satellite s = new Satellite(); 
		
		s.setPaquet(p); 
		
		String x = s.getPaquet().getNomFichier(); 
		
		System.out.print(x);		
		
	}
	
	/*
	 * Auteur : Edouard Laforge 
	 * Test si le type est commande
	 */
	public static void testSetPaquet1() {
		
		/*
		 * Strategie : Pour tester setPaquet, on cr�e un nouveau paquet et on 
		 * set son type a COMMANDE (on va donc tester que l'angle desir� de 
		 * satellite change correctement). On va par la suite cr�er un Satellite
		 * et faire appel � la m�thode setPaquet et on affiche les attributs 
		 * et leurs valeurs avec toString(). 
		 */
		
		Paquet p = new Paquet(); 
		
		p.setTypePaquet(Constantes.COMMANDE);
		
		//Ceci sera l'angle qui deviendra angle desire
		p.setAnglePhoto(50);
		
		Satellite s = new Satellite(); 
		
		s.setPaquet(p);
		
		String x = s.toString(); 
		
		System.out.print(x);
		
		
	}
	
	/*
	 * Auteur : Edouard Laforge 
	 * Test si le type est FIN ou DATA
	 */
	public static void testSetPaquet2() {
		

		/*
		 * Strategie : Pour tester setPaquet, on cr�e un nouveau paquet et on 
		 * set son type a FIN (on va donc tester que ce paquet rentre � 
		 * l'int�rieur de satellite). Nous allons cr�er un nom de fichier unique 
		 * pour pouvoir l'identifier. On va par la suite cr�er un Satellite et 
		 * faire appel � la  m�thode setPaquet et on affiche le nom du paquet � 
		 * l'interieur de se dernier
		 */
		
		Paquet p = new Paquet(); 
		
		p.setTypePaquet(Constantes.FIN);
		
		//Ceci sera le nom du fichier du nouveau paquet
		p.setNomFichier("Bonjour"); 
		
		Satellite s = new Satellite(); 
		
		s.setPaquet(p);
		
		String x = s.getPaquet().getNomFichier(); 
		
		System.out.print(x);
		
	}
	
	/*
	 * Auteur : Edouard Laforge 
	 */
	public static void testDeplacerSatellite() {
		
		
		/*
		 * Strategie : Nous cr�ons tout d'abord un Satellite et on met son 
		 * angle actuel � 10 et son angle d�sir� � 20. Par la suite on affiche
		 * les valeurs ds attributs de la classe Satellite (avec toString). Par 
		 * la suite, on appel la focntion deplacerSatellite en boucle tout en 
		 * affichant l'angle actuel et d�sir� � chaque fin de boucle pour 
		 * v�rifier le bon fonctionnement de la m�thode. 
		 */
		Satellite s = new Satellite();
		
		s.setAngleActuel(10);
		s.setAngleDesire(20);
		
		String x = s.toString();
		System.out.println(x);
		
		int i = 0; 
		
		while(i < 30 ) {
			
			try{
				
				s.deplacerSatellite();
				
			}catch (Exception e){
				
				System.out.print(e);
				
			}
			String y = s.toString();
			System.out.println(y);
			i++;
			
		}
		
	}
	
	public static void testPrendrePhoto(){
			
		Satellite s = new Satellite(); 
		
		try{
			
			s.prendrePhoto(20); 
			
		} catch(Exception e){
			
			System.out.print(e); 
			
		}
		
		for(int i = 0; i < s.nomFichier.size(); i++){
			
			System.out.println(s.nomFichier.get(i)); 
			
		}

		
		System.out.println("Fichier random : " + s.getImage().nomFichier);
		System.out.println("Angle : " + s.getImage().angle);

	}
	
	/***********************
	 *     CLASSE ROBOT	   *
	 ***********************/
		
	/*
	 * Auteur : Edouard Laforge
	 */
	public static void testRobot() {
		
		/*
		 * Strat�gie : Nous allons simplement cr�er une instance de la classe 
		 * Robot et par la suite nous allons afficher ses attributs (et la
		 * valeur par d�faut) avec la m�thode toString(). On peut ainsi v�rifier 
		 * si l'intialisation par d�faut de l'objet c'est faire correctement.  
		 */
		
		Robot r = new Robot();
		
		String x = r.toString();
		
		System.out.println(x); 
		
	}
	
	
	
	
	// TEST ESPACE
	
		/*
		 * Auteur : No�mie St-Onge
		 */
		
		public static void testConstructeurEspace() {
			
		/*
		 * Strat�gie : Nous instanciations un robot, un satellite et un espace et
		 * constuisions l'espace � partir des param�tres robot et satellite. Pour
		 * s'assurer que le le constructeur fonctionne bien, nous affichons sous 
		 * forme de String les param�tres qui forment l'espace (devraient �tre tous
		 * deux null).
		 */
					
			Robot robot = new Robot();
			
			Satellite satellite = new Satellite();
			
			robot = null;
			
			satellite = null;
			
			Espace espace = new Espace(robot, satellite);
			
			String test = espace.toString();
			
			System.out.print(test);
		}	
}


	
	

