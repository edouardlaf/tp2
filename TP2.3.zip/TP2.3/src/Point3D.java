
/*
 *
 * @author Pierre B�lisle
 * @version octobre 2000
 * @modifi� par Edouard Laforge
 */

public class Point3D {
	
	//Les 3 varaibles qui indiqueront les coordonnees d'un point 3D 
	private double x; 
	private double y; 
	private double z; 
	
	//Constructeur par defaut 
	
	public Point3D() {
 
	}
	
	//Constructeur par copie d'attributs 
	
	public Point3D(double newX, double newY, double newZ) {
		x = newX; 
		y = newY; 
		z = newZ; 
	}
	
	//Constructeur par copie d'objet
	
	public Point3D(Point3D p) {
		x = p.x; 
		y = p.y; 
		z = p.z; 
	}
	
	//Accesseur 
	
	public double getX() { 
		return this.x; 
	}
	
	public double getY() { 
		return this.y; 
	}
	
	public double getZ() { 
		return this.z; 
	}
	
	//Mutateur
	
	public void setX(double x) {
		this.x = x; 
	}
	
	public void setY(double y) {
		this.y = y; 
	}
	
	public void setZ(double z) {
		this.z = z; 
	}
	
	
	//!!!!! NE PAS OUBLIER DE METTRE DROIT D'AUTEUR !!!!!
	
	
	 /**************************************************
    *
    * LES COMPORTEMENTS (Par  Pierre Belisle)
    *
    **************************************************/
    /**
     * Calcul la distance entre le point actuel
     * et un autre point
     * @param le point � consid�rer
     * @return la racine carr�e de la somme des diff�rences en x, en y, et en z
     *  au carr�
     */
    public double distance (Point3D point){
        return Math.sqrt(Math.pow(point.x-x,2) + Math.pow(point.y-y,2) + 
        		Math.pow(point.z-z,2));
    }


    /**
     * Calcul la pente de la droite form�e par le point actuel
     * et un autre point
     * @param le point � consid�rer
     * @return la diff�rence de y divis� par la diff�rence des x
     *
     */
    public double pente (Point3D point){
        return (point.y-y) / (point.x-x);
    }


    /**
     * Calcul le point au centre entre le point actuel et un autre point
     * @param le point � consid�rer
     * @return les diff�rences en x,y et z divis� par 2
     *
     */
    public Point3D milieu (Point3D point){
        return new Point3D(Math.abs((x-point.x)/2),Math.abs((y-point.y)/2), 
        		Math.abs((z-point.z)/2));
    }


    /**
     * Retourne le point actuel sous forme de la cha�ne "(x,y,z)"
     */
    public String toString(){
        return "(" + x + "," + y + "," + z + ")";
    }


    /**
     * Retourne vrai si le point actuel est �gal � un autre point
     * @param le point � consid�rer
     * @return vrai si tous les attributs sont �gaux
     */
    public boolean equals(Point3D point){
        return point.x == x && point.y == y && point.z == z; 
    }

    /**
     * Retourne une copie du point actuel
     */
    public Object clone(){        	   
        return new Point3D(x,y,z);
    }
}