
public class Constantes {
	
	/*
	Fichier de d�clarations de constantes consid�r�s dans la simulation.

	En lien avec �nonc� du travail inf111 hiver2019 (voir �nonc�).

	Auteur : Pierre B�lisle
	Copyright: Hiver 2019
	*/

	/* Sert � d�finir le nombre de fichiers pouvant �tre trait�s simultan�ment
	   par le robot.*/
	public static final int MAX_FICHIERS = 20;

	// Maximum de caract�res pour un id.
	public static final int MAX_CAR_ID = 100;

	// Le nom du fichier contenant les positions les images.
	public static final String NOM_FICHIER  = "ficAEmettre.txt";

	// Types de paquet.
	public static final int VIDE = 0;
	public static final int FIN = 1;
	public static final int DATA = 2;
	public static final int COMMANDE = 3;

	// On a des gros fichier mais des petits paquets.
	public static final int NB_OCTETS_PAQUETS = 5000;

}
