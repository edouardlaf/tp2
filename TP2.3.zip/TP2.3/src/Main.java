// pour pouvoir �crire dans un fichier
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;


public class Main {
	
	/****************
	 * CONSTANTES
	 ****************/
	public final static String NOM_FICHIER_TERRE = "terre//copie.jpg";

	
	/**********************************************************************
	 * PROGRAMME PRINCIPAL
	 * 
	 * Auteurs : �douard Laforge, Trung Pham, No�mie St-Onge et 
	 * 			 Jeff Vall�e-Sarazzin 	 
	 **********************************************************************/
	
	
	public static void main(String[] Args) throws IOException{
		

		/*
		 * Strat�gie : Boucle de type while qui dure tant que le
		 * fichier n'est pas referm�. La Terre re�oit des paquets 
		 * de l'espace qui sont ins�r�s dans une liste de paquets
		 * si ceux-ci ne sont pas vides.  Si l'espace envoie 
		 * un paquet de type FIN et que l'image est toute re�ue 	 	 
		 * (tous les paquets de l'image sont re�us), l'image est 	 	 
		 * enregistr�e sour forme d'octets sur un fichier. Le 	 	 
		 * fichier est ensuite referm� (fin de la boucle).
		 */ 

		
		/****************************
		 * instanciations des objets
		 ****************************/
		Satellite satellite = new Satellite();
		
		Robot robot = new Robot();
		
		Espace espace = new Espace(robot, satellite);
		
		Paquet paquet1;

		// paquet-commande
		Paquet paquet2 = new Paquet(Math.PI/2, Constantes.COMMANDE);
		
		// fichier dans lequel sera �crit le tableau du nombre d'octets des 
		// paquets
		FileOutputStream f = new FileOutputStream(creationFichier());
		
		// cr�ation de la liste qui contiendra les paquets
		ArrayList<Paquet> listePaquets = new ArrayList<Paquet>();
		
		boolean fichierEcris = false; 
		
		
		// le paquet est pass� � l'espace
		espace.setPaquet(paquet2);
		
		/********************************************************************
		 *  boucle qui communique avec l'espace tant que le fichier n'est pas
		 *  �crit sur le disque dur
		 ********************************************************************/
		
		while (fichierEcris == false){
			
			
			// l'espace envoie un paquet
			paquet1 = espace.getPaquet();
			espace.setPaquet(paquet1);
			
			// si le paquet n'est pas vide, on l'ajoute � la liste de paquets
			if (paquet1 != null){
				
				// ajout
				listePaquets.add(paquet1);				
				
				/*
				 *  si le paquet est de type FIN et que l'image a toute �t� 
				 *  re�ue, le tableau du nombre d'octets est ajout� au fichier
				 */
				
				if (paquetFinal(paquet1) ) {
					
					try {					
						
						ecrirePaquets(listePaquets, f);
					}
					
					
					catch (FileNotFoundException erreur1) {
						erreur1.printStackTrace();
					}
					
					catch (IOException erreur2) {
						System.out.println("Effeur � la fermeture du"
								+ " fichier" + erreur2);
					}
					
					finally {
							
						// fermeture du fichier
						f.close();
						fichierEcris = true; 
						
						
					}
					
				}	
				
			}
					
		}
		 	
	}
	
	
	

	/**
	 * Auteur : No�mie St-Onge
	 * 
	 * Permet la cr�ation d'un fichier
	 * 
	 * @return le fichier cr��
	 */
	public static File creationFichier() {
		
		File fichier = new File(NOM_FICHIER_TERRE);
		
		return fichier;
	}
	
	
	/**
	 * Auteur : No�mie St-Onge
	 * 
	 * V�rifie si le paquet re�u est vide ou non
	 * 
	 * @param paquet Paquet re�u
	 * @return vrai si le paquet est vide, faux s'il ne l'est pas
	 */
	public static boolean paquetVide(Paquet paquet) {
		
		return paquet.getType() == Constantes.VIDE;
	}
	
	
	/**
	 * Auteur : No�mie St-Onge
	 * 
	 * V�rifie si le paquet re�u est la paquet final
	 * 
	 * @param paquet Paquet re�u
	 * @return vrai si le paquet est le paquet final, faux s'il ne l'est pas
	 */
	public static boolean paquetFinal(Paquet paquet) {
		
		return paquet.getType() == Constantes.FIN;
	}
	
	
	
	/**
	 * Auteur : No�mie St-Onge
	 * 
	 * V�rifie si l'image est toute re�ue
	 * 
	 * @param robot Robot qui a pris l'image en photo
	 * @param liste Liste qui contient les paquets formant l'image
	 * @return vrai si l'image est toute re�ue, faux si elle ne l'est pas
	 */
	public static boolean imageTouteRecue(Paquet paquet, ArrayList<Paquet> 
	liste){
		
		return paquet.getOrdrePaquet() == liste.size();
	}
	
	
	/**
	 * Auteur : No�mie St-Onge
	 * 
	 * �criture des paquets dans le fichier un a un
	 * 
	 * @param liste Liste qui contient les paquets
	 * @param f Fichier FileOutputStream
	 * @throws IOException 
	 */
	public static void ecrirePaquets(ArrayList<Paquet> liste, FileOutputStream 
			f) throws IOException {
		
		/*
		 * Strat�gie : boucle qui �crit les paquets de la liste un � un 
		 * dans le fichier. Lorsqu'on obtient un fichier de type fin, on
		 * l'�crit, puis la boucle se termine ensuite.
		 */
		for (Paquet i : liste){
			
			
			if(i.getType() == Constantes.FIN) {
				f.write(i.getBuffer());
				break;	
			}
			
			else {
				f.write(i.getBuffer());
			}
		}
	}
		
}
