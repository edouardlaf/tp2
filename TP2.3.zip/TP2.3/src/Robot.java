import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

/*
Le robot lunaire (rover) recoit des images du satellite et il doit les 
d�composer en paquets pour les retourner au satellite.

Trois m�thodes seulement : 

         Robot : Constructeur essentiel au bon fonctionnement pour une premi�re 
		 utilisation.

		 setImage : Si l'image n'est pas NULL, pr�pare � la d�composition en 
		 paquets.

		 getPaquet : Retourne un paquet d'une image command�e. Pour l'instant
		             les fichiers sont reconstruits un � la fois dans l'ordre
		             d'ouverture.
		 
Auteur : Pierre B�lisle
@Copyright H2019
 */

public class Robot {
	
	// 80% du temps, les paquets sont corrects, le reste du temps sont � null.
	private static double PROB_PAQUET_NON_NULL = .8;
	
	/* Donn�es retenues sur les fichiers pour simplifier les algorithmes.*/
	private class InfoFichier{

		// Total d'octets du fichier.
		int tailleFichier;

		// Position du paquet dans le fichier.
		int indiceCourant;

		// Nom du fichier en sortie et l'angle de la prise de photo.
		ImageLune image;

		// Maintient du nombre d'octets � jour.
		long nbTotalOctetsEmis;

		/* R�f�rence vers le fichier qui contient l'image � transmettre.*/
		FileInputStream ptrFichier;

	};


	/* Le robot conserve les images en multiples paquets
       d�compos� par setImage.*/

	// Contient les infos sur tous les fichiers ouverts en même temps.
	InfoFichier[] tabFichiers = null;

	int nbFichiers = 0;

	/*
	 *   Proc�dure locale qui ferme tous les fichiers potentiellement ouverts
	 *   et met tout le tableau 0.
	 */
	private void initTabFichiers()
	{
		int i = 0;

		if(tabFichiers[0] != null) {

			for (i = 0; i < Constantes.MAX_FICHIERS; i++)
			{
				if(tabFichiers[i].ptrFichier != null)
				{
					try {
						tabFichiers[i].ptrFichier.close();
						
						tabFichiers[i].ptrFichier = null;

						tabFichiers[i].nbTotalOctetsEmis = 0;
						tabFichiers[i].indiceCourant = 0;
						tabFichiers[i].tailleFichier = 0;
						
						tabFichiers[i].ptrFichier = null;

					} catch (IOException e) {
						
						e.printStackTrace();
					}
				}
			}
		}
	}

	/**
	 * Constructeur qui s'assure de pouvoir commencer � prendre des images et
	 * les d�composer en paquets.
	 */
	public Robot() {
		
		tabFichiers = new InfoFichier[Constantes.MAX_FICHIERS];

		initTabFichiers();
		
		nbFichiers = 0;

	}


	/*
	 * Utilitaire priv� qui d�cale les donn�es du tableau de fichiers
	 * d'une case � gauche � partir de num_f.
	 */

	private void decalerGauche(int num_f) {
		
		if(nbFichiers < Constantes.MAX_FICHIERS - 1) {
			
			for (int i = num_f; i < nbFichiers; i++) {

				tabFichiers[i] = tabFichiers[i + 1];
			}		
		}
	}
	
	/* 
	 * Enlève le fichier � la position idFichier en d�calant � gauche 
	 * et nbFichiers --.
	 *  
	 * Aucune validation de num_f
	 */
	private void supprimer_fichier(int idFichier)
	{

		try {
			// On le ferme d'abord.
			tabFichiers[idFichier].ptrFichier.close();

			System.out.println("fermeture fichier robot : "+ 
		              tabFichiers[idFichier].image.nomFichier);

    		// D�calage � gauche
			decalerGauche(idFichier);
	
			nbFichiers--;

		} catch (IOException e) {
			
			e.printStackTrace();
		}
	}

	/** 
	 * 	GET_PAQUET_ROBOT
	 * 	Retourne un paquet d'une image command�e ou un paquet null.
	 *
	 * 	@param 
	 *  	Aucun
	 *  
	 *  @return
	 *  	Un paquet d'une image ou un paquet vide.
	 */
	Paquet getPaquet() {

		/* 
		 *  Strat�gie : S'il y a au moins une image, on choisi un fichier
		 *  au hasard et on envoie le paquet o� le curseur est positionn� 
		 *  dans le fichier. 
		 *  
		 *  Si le fichier a �t� envoy� au complet, on envoie un paquet 
		 *  de fin de transmission (FIN) et on ferme le fichier.
		 */

		// On choisit un fichier au hasard.
		int num_f;

		// Sert obtenir le nombre lu avec un fread.
		int nbOctetsLus;

		Paquet paquet = null;

		if (nbFichiers != 0){

			// Un fois de temps en temps, on envoie un paquet null.
			if(Math.random() < PROB_PAQUET_NON_NULL) {

				// Un paquet vide au d�part.
				paquet = new Paquet();
				
				// On termine un fichier � la fois.
				num_f = 0;

				// Tente de lire les octets et affecter le total d'octets lus.
				try {
					nbOctetsLus = tabFichiers[num_f].
							        ptrFichier.read(paquet.getBuffer(),
									0,
									Constantes.NB_OCTETS_PAQUETS);

					ajusterPaquet(num_f, nbOctetsLus, paquet);

					ajouterAngleANomFichier(num_f, paquet);

					ajusterTabFichiers(num_f, nbOctetsLus, paquet);


				} catch (IOException e) {

					e.printStackTrace();
				}
			}
		}

		return paquet;		
	}

	/*
	 * Ajuste les donn�es du tableau de fichiers.  S'assure de donner
	 * le bon type de paquet au paquet et de supprimer le fichier s'il est 
	 * transmis.
	 */
	private void ajusterTabFichiers(int num_f, int nbOctetsLus, Paquet paquet) {


		// Augmentation du total des octets �mis.
		tabFichiers[num_f].nbTotalOctetsEmis += (long) nbOctetsLus;

		// Le num�ro du paquet.
		tabFichiers[num_f].indiceCourant++;
		
		/* Contrôle sur le fichier, on a lu un paquet
		   mais si on a lu le dernier paquet,   on ferme le fichier,
		   on s'en d�barrasse dans le tableau.*/
		if (tabFichiers[num_f].nbTotalOctetsEmis ==
			tabFichiers[num_f].tailleFichier) {
			
			// C'est le dernier paquet.
			paquet.setTypePaquet(Constantes.FIN);

			// D�caler les autres � gauche et d�cr�m�mente le nombre de fichiers.
			supprimer_fichier(num_f);
		}
		else{
			
			paquet.setTypePaquet(Constantes.DATA);
		}


	}
	

	/*
	 * Ajuste les donn�es du paquet.
	 */
	private void ajusterPaquet(int num_f, int nbOctetsLus, Paquet paquet) {
		
		// On retient la partie entière de la division.
		double nb_paquets_d = tabFichiers[num_f].tailleFichier /
				(double)Constantes.NB_OCTETS_PAQUETS;

		paquet.setNbTotalPaquets((int) Math.ceil(nb_paquets_d));
		
		// Seulement utile pour le dernier paquet mais n�cessaire.
		paquet.setNbEffectifOctets(nbOctetsLus);

		
		// Position du paquet dans le fichier.
		paquet.setNumPaquet(tabFichiers[num_f].indiceCourant);		
	}

	/*
	 * Ajoute l'angle au nom de fichier avant l'extension.
	 */
	private void ajouterAngleANomFichier(int num_f, Paquet paquet) {
		
		final int NB_CAR_EXT = 4;
		
		// Copy le nom de fichier avec l'angle.
		int taille = tabFichiers[num_f].image.nomFichier.length();
		int posExt = taille - NB_CAR_EXT;
		
		String nom = 
			  tabFichiers[num_f].image.nomFichier.substring(0, posExt);
		
		String ext = 
		  tabFichiers[num_f].image.nomFichier.substring(posExt, taille);
		
		paquet.setIdUnique(nom + "_" + 
		                   tabFichiers[num_f].image.angle + ext);		
	}

	/*
	 * Retourne si le fichier est d�j� ouvert.
	 */
	private boolean fichierExiste(String nomFic) {
		int i = 0;
		boolean existe = false;

		// S'il n'y a aucun fichier, le fichier n'existe pas.
		if (nbFichiers != 0)
		{

			/* S'il est ouvert mais pas termin�, il n'est pas � r�ouvrir.
			 * On le cherche ici.
			 */
			while (i < nbFichiers && 
				!tabFichiers[i].image.nomFichier.equals(nomFic))
			{
				i++;
			}

			existe = i < nbFichiers;

		}

		// Test suppl�mentaire si i == 0 et que le fichier n'est pas ouvert.
		return existe;
	}

	/**
	 * 	SET_IMAGE
	 * 	Ajoute une image � d�composer au robot.
	 *
	 *	@param image Le nom du fichier contenant l'image � d�composer.
	 *
	 *	@return true si l'image a bien �t� saisie et false autrement.
	 */
	public void setImage(ImageLune imageLune) {
		
		/* 
		 * Strat�gie: On ne d�compose pas r�ellement en paquets, on joue 
		 * avec la position courante incluse dans FILE* � chaque saisie.
		 * 
		 * Ici, on ajoute simplement le lien logique au tableau de fichiers qui
		 * est consid�r� comme le tableau d'images prises par le satellite.
		 * 
		 * Le fichier sera ferm� par getPaquet.
		 */

		boolean success  = false;

		if (tabFichiers[nbFichiers] == null && 
			imageLune != null && 
			imageLune.nomFichier != null){
			
			/* Retour d'information sur la r�ussite ou nom d'ouverture 
			 * du fichier.*/
			success = !fichierExiste(imageLune.nomFichier);

			if (success)
			{
				File fic = new File("satellite//" + imageLune.nomFichier);

				try {

					tabFichiers[nbFichiers] = new InfoFichier();

					tabFichiers[nbFichiers].ptrFichier = 
							                          new FileInputStream(fic);

					tabFichiers[nbFichiers].image = imageLune;

					// Obtenir la taille du fichier en Java.
					tabFichiers[nbFichiers].tailleFichier = (int) fic.length();

					tabFichiers[nbFichiers].indiceCourant = 0;

					
					if(nbFichiers == 0)
					
						System.out.println("cr�ation fichier robot : "+ 
						              tabFichiers[nbFichiers].image.nomFichier);

					nbFichiers++;		

					success = true;

				} catch (FileNotFoundException e) {
					tabFichiers[nbFichiers].image = null;
				}
			}

		}
			
	}
}