import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.Reader;
import java.util.ArrayList;
import java.util.Scanner;

/*
 * Objet qui sera en orbite autour de la lune.
 * Le satellite recevera qu'une seul commande qui contiendra
 * l'angle de prise de la photo. Au moment ou l'objet sera dans
 * l'angle, il prendra une photo. Le nom du fichier sera retenu en
 * memoire.
 * 
 * @autor Edouard Laforge et Noemie St-Onge
 */


public class Satellite {
	
	//Constantes avec valeurs fictives 
	static final double RAYON_PLANETE = 1;
	static final double RAYON_ORBITE = 2;
	static final double NB_PAS_REVOLUTION = 1200;
	static final double DELTA_ANGULAIRE = 
			((2* Math.PI)/NB_PAS_REVOLUTION);

	//paquet destin/ a la terre
	private Paquet paquet = new Paquet();
	//nom de la derniere image prise
	private ImageLune image = new ImageLune(); 
	//angle desirer pour prendre la photo
	private double angleActuel;
	// pour l'instant l'angle est en rad 
	private double angleDesire; 
	//position actuelle calculee par le satellite
	private Point3D position; 
	// collection des noms noms de fichiers 
	ArrayList<String> nomFichier; 
	// liste d'angles 
	Liste listeAngles; 
	
	
	/** 
	 * Auteur : Edouard Lagorge
	 * Constructeur qui initialise les attributs par defaut 
	 * 
	 */
	
	public Satellite() {
	
		 
		double angleActuel = 0.0; 
		position = new Point3D(RAYON_PLANETE, 
				RAYON_ORBITE * Math.sin(angleActuel), 
				RAYON_ORBITE * Math.sin(angleActuel)); 
		

		
		//Pour les tests 
		System.out.println("Creation d'un nouveau sattelite");
		
		listeAngles = new Liste();
		
	}
	
	
	/**
	 * @Auteur : Edouard Laforge 
	 * Accesseur du paquet destin� � la Terre 
	 * @return retourne le paquet destin� � la Terre
	 */
	
	public Paquet getPaquet() {
		return this.paquet;
	}
	
	/**
	 * @Auteur : Edouard Laforge 
	 * Accesseur pour l'image
	 * @return retourne la derni�re image prise 
	 */
	public ImageLune getImage() { 
		return this.image; 
	}
	
	/**
	 * @Auteur : Edouard Laforge 
	 * Re�oit un paque et le tra�te selon son type  
	 * @param paquet qui se fait tra�ter 
	 */
	
	public void setPaquet(Paquet paquet) {
		
		/*
		 * Strategie : Avec getType(), on peut trouver le type du paquet envoyer
		 * et en utilisant des if else if on peut tra�ter ce paquet de 
		 * diff�rente m�thode. Si le type est COMMANDe' on renvoie l'angle du 
		 * paquet alors que si le type est DATA ou FIN on met le paquet recu � 
		 * l'int�rieur de la classe satellite. 
		 */
		
		if(paquet != null && paquet.getType() == Constantes.COMMANDE) {
			
			this.angleDesire = paquet.getAnglePhoto();
			
			insererAngle(angleDesire);
			
			this.paquet = null; 
			
		}else {
			
				this.paquet = paquet;
				
		}
	}
	

	
	/** 
	 * @Auteur : Edouard Laforge
	 * Met le nom de la derni�re image � lunar-surface-1.jpg
	 * 
	 */
	//private void setImage(ImageLune image) {
		//this.image = image;
	//}
	
	
	//Utiliser pour des tests seulement
	public void setAngleActuel(double angle) {
		this.angleActuel = angle; 
	}
	
	public void setAngleDesire(double angle) {
		this.angleDesire = angle; 
	}
	
	
	/**
	 * @Auteur : Edouard Laforge 
	 * Methode qui affiche tous les attributs et leur valeur (pour test) 
	 * @return Retourne un String contenant l'information 
	 */
	
	public String toString() {
		return "image : " +image+ " angle actuel: " +angleActuel + 
				" angle desire: " + angleDesire + position.toString();
	}
	
	/**
	 * M�thode qui avance le satellite jusqu'� se qu'il soit � son angle d�sir�
	 * @throws FileNotFoundException 
	 * @author Edouard Laforge
	 */
	public void deplacerSatellite() throws FileNotFoundException {
		
		/*
		 * Strategie : � chaque fois qu'on va utiliser cette fonction, on va 
		 * actualiser l'angle et la position du satellite et on va comparer 
		 * cette position avec la position d�sir� (calculer avec l'angle 
		 * d�sir�). Si la distance entre ces deux points est plus petite que
		 * 0.001, on fait appel � la fonction prendrePhoto() (qui ne fait rien 
		 * pour l'instant)
		 */
	
		//Actualise l'angle actuel 
		angleActuel = Math.abs(angleActuel + (DELTA_ANGULAIRE ))% (2 * Math.PI); 
		
		
		//Calcul de la nouvel position selon l'angle actualis�
		position.setX(RAYON_ORBITE * Math.cos(angleActuel));
		position.setY(RAYON_ORBITE * Math.sin(angleActuel));
		
		
		//Calcul la position du satellite selon l'angle d�sir� 
		Point3D positionDesire = new Point3D(
				RAYON_ORBITE * Math.cos(angleDesire),
				RAYON_ORBITE * Math.sin(angleDesire),
				position.getZ());
		
		//Si il est � la bonne position, il prend une photo 
		//Calcul la distance avec la m�thode distance de point3D
		if(position.distance(positionDesire) < 0.001 ){
			
			System.out.println("prise de la photo"); //pour test
			
			prendrePhoto(angleDesire);
			
			try {
				listeAngles.supprime();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
		}else{
			
			this.image = null; 
			
		}
		
	}
	
	/**
	 * @author Edouard Laforge
	 */
	public void prendrePhoto(double angle) throws FileNotFoundException {
		
		File fichier = new File("ficAEmettre.txt"); 
		
		Reader r = new FileReader (fichier); 
		
		BufferedReader b = new BufferedReader(r); 
		
		Scanner s = new Scanner(b); 
		
		image = new ImageLune(); 

		
		
		if(this.nomFichier == null || this.nomFichier.size() == 0){
			
			nomFichier = new ArrayList<String>();
			
			while(s.hasNext()){
				nomFichier.add(s.next()); 
			}
			try{
				r.close(); 
				b.close();
				s.close(); 
			} catch(Exception e){
				System.out.print(e); 
			}
		}
		
		int random = (int)(Math.random() * nomFichier.size()); 
		
		this.image.angle = angle; 
		this.image.nomFichier = nomFichier.get(random); 
	}
	
	public void insererAngle(double angle) {
		
		if(listeAngles.estVide()) {
			
			listeAngles.insererDebut(angle);
			
		}
		else if(angle > this.angleActuel) {
			
			if(angle < (double)listeAngles.getDebut()) {
				
				listeAngles.insererDebut(angle);
				
			}else {
				
				int i = 0; 
				
				try {
					while((double)listeAngles.getElement(i) > angle && 
							(double)listeAngles.getElement(i) < this.angleActuel) {
						
						i++; 
						
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				try {
					listeAngles.insererAPositionDonnee(angle, i);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} // A FAIRE 
				
			}
			
		}
		else if(angle < this.angleActuel) {
			
			if(angle > (double)listeAngles.getFin()) {
				
				listeAngles.insererFin(angle);
				
			} else {
				
				//Commence � la fin du tableau 
				int i = listeAngles.getNbElements() - 1; 
				
				try {
					while((double)listeAngles.getElement(i) < angle && 
							(double)listeAngles.getElement(i) < this.angleActuel) {
						
						i--;
						
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				try {
					listeAngles.insererAPositionDonnee(angle, i);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} // A FAIRE 
				
			}
			
		}
		
	}
	
}
