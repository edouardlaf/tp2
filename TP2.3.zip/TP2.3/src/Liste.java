
public class Liste {

	private class Noeud {
		
		private Object element;
		private Noeud suivant; 
		
		public Noeud(Object element, Noeud suivant) {
			this.suivant  = suivant; 
			this.element = element;
		}
		
	}
	
	private Noeud debut; 
	private Noeud fin; 
	private Noeud pC; 
	private int nbElements; 
	
	
	/*
	 * Constructeur
	 */
	
	//Constructeur par defaut
	public Liste() {
		initListe();
	}
	
	private void initListe() {
		debut = null;
		fin = null;
		pC = null;
		nbElements = 0;
	}
	
	/*
	 * Accesseurs
	 */
	
	/**
	 * Retourne le nombre d'elements dans la liste
	 * @author Trung Pham
	 * @return nbElements nombre d'elements dans la liste
	 */
	public int getNbElements() {
		return nbElements;
	}
	
	/**
	 * Retourne l'element du debut de la liste
	 * @author Trung Pham
	 * @return debut.element element du debut de la liste
	 */
	public Object getDebut() {
		
		if(nbElements == 0) {
			System.out.println("La liste est vide.");
		}
		return debut.element;
	}	
	
	public Object getFin() {
		if(nbElements == 0) {
			System.out.println("La liste est vide.");
		}
		return fin.element;
	}
	
	/**
	 * Renvoit l'�l�ment � la position d�sir�e 
	 * @author Edouard Laforge
	 * @param x position d�sir�e 
	 * @return l'objet qui se trouve � la position d�sir�e 
	 */
	public Object getElement(int x) throws Exception {
		
		/*
		 * Strat�gie : On cr�e un noeud qui commence au d�but et aussi un 
		 * it�rateur qui garde en m�moire la position de ce noeud. On passe � 
		 * la position suivante en autant que i ne soit pas �gale � la position 
		 * x d�sir�e ou que la position ne soit pas null. On retourn finalement 
		 * l'�l�ment � la position ou nous sommes rendu � la fin de la boucle 
		 * (seulement si la position n'est pas null). 
		 */
		Noeud position = debut; 
		
		int i = 1; 
		
		while(i != x && position != null) {
			
			position = position.suivant; 
			i++; 
			
		}
		
		if(position != null) {
			return position.element; 
		}
		
		else if(x >= nbElements || x < 0) {
			throw new Exception("La position entree est invalide");
		}
		
		return null; 
		
	}
	
	/**
	 * Met la position courante au debut
	 * @author Edouard Laforge
	 * 
	 */
	public void setPCDebut() {
		pC = debut; 
	}
	/**
	 * Met la position courante � la fin 
	 * @author Edouard Laforge
	 */
	public void setPCFin() {
		pC = fin; 
	}
	
	/**
	 * Met la position courante � la position suivante 
	 * @author Edouard Laforge
	 */
	public void setPCSuivant() {
		pC = pC.suivant; 
	}
	
	/**
	 * Retourne si le tableau est vide ou non 
	 * @return valeur boolean vrai si le tableau est vide
	 * @author Edouard Laforge
	 */
	public boolean estVide() {
		
		return nbElements == 0; 
		
	}
	/**
	 * Met la position cuorante � la position pr�c�dente 
	 * @author Edouard Laforge 
	 */
	public void setPCPrecedent() {
		
		Noeud tmp = debut; 
		
		while(tmp.suivant != pC) {
			
			tmp = tmp.suivant; 
			
		}
		
		pC = tmp; 
	}
	
	/**
	 * Insere un �l�ment au d�but de la liste 
	 * @param element element envoy� par lors de l'appel de la fonction 
	 * @author Edouard Laforge
	 */
	public void insererDebut(Object element) {
		
		/*
		 * Strat�gie : On cr�e un nouveau noeud que l'on met au d�but de la 
		 * liste et si la liste est vide, ce noeud devient aussi la fin.
		 * Finalement, on met la position courante sur ce nouvelle �l�ment 
		 * et on incr�mente le nombre total d'�l�ments. 
		 */
		
		debut = new Noeud(element, debut); 
		
		if(nbElements == 0){
			
			fin = debut; 
			
		}
		
		pC = debut; 
		
		nbElements++; 
	}
	
	/**
	 * Insere un element a la fin de la liste
	 * @author Trung Pham
	 * @param element element a inserer a la fin
	 */
	
	public void insererFin(Object element) {
		
		setPCFin();
		insererAPC(element);
		
	}
	
	/**
	 * Insere un �l�ment � la position courante est met la position courante 
	 * � cette valeur
	 * @param element element qui est plac� dans la liste 
	 * @author Edouard Laforge 
	 */
	public void insererAPC(Object element) {
		
		if(nbElements == 0 || pC == debut) {
			
			insererDebut(element); 
			
		}else {
			
			Noeud noeud = new Noeud(pC.element, pC.suivant);
			
			pC.element = element; 
			
			pC.suivant = noeud; 
			
			if(noeud.suivant == null) {
				
				fin = noeud; 
				
			}
			
			nbElements++; 
		}
		
	}
	
	/**
	 * supprime l'�l�ment se trouvant � la position courante 
	 * @author Edouard Laforge
	 * @exception exception si le tableau est vide
	 */
	public void supprime() throws Exception {
		
		/*
		 * Stratt�gie : On regarde toute les situations possibles (pC � la fin,
		 * au d�but, au millieu ou bien lorsqu'il y a qu'un seul �l�ment) et 
		 * supprimons l'�l�ment sur la position courante selon la situtation.
		 */
		
		// Si le tableau est vide on lance une exception 
		if(estVide()) {
			
			throw new Exception("Le tableau est vide"); 
			
		}
		
		// Si il y a seulement un �l�ment , on met le pC, le d�but 
		// et la fin � null
		if(debut == fin) {
			
			debut = fin = pC = null;  
			
		}
		
		// Si la position courante se retrouve au d�but, on met le d�but comme 
		// �tant �gale � l'�l�ment suivant de la position courante. 
		else if(pC == debut) {
			
			debut = pC.suivant; 
			
		}
		
		else {
			
			/*
			 * Si la position courante est � la fin, on recule la position 
			 * courante d'une case et on met la fin � cette case. De plus, on 
			 * met sa r�f�rence de la prochaine case � null
			 */
			if(fin == pC) {
				
				setPCPrecedent(); 
				fin = pC; 
				pC.suivant = null; 
				
			}else {
				
				/*
				 * Si l'�l�ment � supprimer se trouve entre le d�but et la fin, 
				 * on �crase ses donn�es avec celle du prochaine �l�ment 
				 */
				pC.element = pC.suivant.element; 
				pC.suivant = pC.suivant.suivant;
				
				
				/* Dans le cas ou nous avons enlever l'avant dernier, il faut 
				 * s'assurer de mettre la r�f�rence de lui qui prend sa place
				 * (soit le dernier) � null 
				 */
				if(pC.suivant == null) {
					
					fin = pC; 
					
				}
				
			}
			
		}
		
	}
	
	
	/**
	 * Insere un element a une position precise dans la liste
	 * 
	 * @autor Trung Pham
	 * @param element element place dans la liste
	 * @param position la nieme position a laquelle nous voulons inserer l'element
	 * @throws Exception si la position donnee est negative ou plus grande que le nbElements
	 */
	public void insererAPositionDonnee(Object element, int position) throws Exception{	

		/*
		 * Strategie: Il s'agit de prendre la position a laquelle nous voulons inserer
		 * et incrementer avec une boucle for un iterateur jusqua ce que la valeur de 
		 * la position est atteinte. A chaque incrementation, on deplace la position 
		 * courante de 1 element en la partant de la position de debut. Une fois la
		 * position courante a la position desiree, on fait appelle a la fonction qui
		 * inserera l'element a la position courante. Si position entree est 0, on 
		 * fait qu'appeler la fonction insererDebut. Si la position entree est negative
		 * ou plus grandre que le nombre d'element, on lance l'exception.
		 */
		
		if(position >= nbElements) {
			throw new Exception("La position donnee est plus grande que le nombre d'elements.");
		}
		
		else if(position < 0) {
			throw new Exception("La position donnee est negative.");
		}
		
		else if(position == 0) {
			insererDebut(element);
		}
		
		else {
			//on met la position courante a la premiere valeur
			setPCDebut();
		
			//avec un iterateur, on deplace la position courante jusqu'a la position desiree
			for(int i = 0; i < position; i++) {
			
				setPCSuivant();
			
			}
		
			insererAPC(element);
		}
	}
	
	/**
	 * Affiche tout les elements d'une liste
	 * @author Trung Pham
	 */
	
	public void afficherListe(){
		
		/*
		 * Strategie: on met la position courante au debut. On cree une
		 * boucle for qui affiche l'element de la position courante et
		 * deplace la position courante de une position tant que 
		 * l'iterateur est inferieur au nombre d'elements.
		 */
		
		//on met la position courante au debut de la liste
		setPCDebut();
		
		/*
		 *affichage de tout les elements de la liste par une boucle
		 *for
		 */
		
		System.out.print('[');
		
		for(int i = 0; i < nbElements; i++) {
		
			System.out.print(pC.element +  " ");
			
			pC = pC.suivant;
		}
		
		System.out.println(']');
	}
	
}