
public class Paquet {
	
	//tableau de NB_OCTETS_PAQUETS
	private byte[] Octets = new byte[Constantes.NB_OCTETS_PAQUETS]; 
	//nombre effectif d'octets dans le tableau
	private int nbOctets; 
	//angle de prise de la photo
	private double anglePhoto; 
	//le type de paquet peut etre COMMANDE, DATA, VIDE ou FIN de la classe
	//constante
	private int type;
	private int ordrePaquet; 
	//nombre total de paquet pour l'image
	private int nbPaquets; 
	private String nomFichier;
	
	

	//Constructeur par defaut 
	
	public Paquet() {}
	
	//Constructeur par copie d'attributs 
	
	public Paquet(byte[] Octets, int nbOctets, double anglePhoto, int type, 
			int ordrePaquet, int nbPaquets, String nomFichier) {
		this.Octets = Octets; 
		this.nbOctets = nbOctets; 
		this.anglePhoto = anglePhoto; 
		this.type = type; 
		this.ordrePaquet = ordrePaquet; 
		this.nbPaquets = nbPaquets; 
		this.nomFichier = nomFichier; 
	}
	
	/*
	 * Constructeur utiliser dans le main (prend seulement un type et un angle
	 * de photo  
	 */
	public Paquet(double anglePhoto, int type) {
		
		this.anglePhoto = anglePhoto; 
		this.type = type; 
		
	}
	
	//Constructeur par copie d'objet
	
	public Paquet(Paquet p) {
		this.Octets = p.Octets; 
		this.nbOctets = p.nbOctets; 
		this.anglePhoto = p.anglePhoto; 
		this.type = p.type; 
		this.ordrePaquet = p.ordrePaquet; 
		this.nbPaquets = p.nbPaquets; 
		this.nomFichier = p.nomFichier; 
	}
	
	//Accesseurs
	
	public byte[] getBuffer() {
		return this.Octets; 
	}
	
	public int getNbOctets() {
		return this.nbOctets; 
	}
	
	public double getAnglePhoto() {
		return this.anglePhoto; 
	}
	
	public int getType() {
		return this.type; 
	}
	
	public int getOrdrePaquet() {
		return this.ordrePaquet;
	}
	
	public int getNbPaquets() {
		return this.nbPaquets;
	}
	
	public String getNomFichier() {
		return this.nomFichier; 
	}
	
	
	//Mutateurs 
	
	public void setOctets(byte[] Octets) {
		this.Octets = Octets; 
	}
	
	public void setNbEffectifOctets(int nbOctets) {
		this.nbOctets = nbOctets;
	}
	
	public void setAnglePhoto(double anglePhoto) {
		this.anglePhoto = anglePhoto;
	}
	
	public void setTypePaquet(int type) {
		this.type = type; 
	}
	
	public void setNumPaquet(int ordrePaquet) {
		this.ordrePaquet = ordrePaquet;;
	}
	
	public void setNbTotalPaquets(int nbPaquets) {
		this.nbPaquets = nbPaquets; 
	}
	
	public void setNomFichier(String nomFichier) {
		this.nomFichier = nomFichier;
	}
	
	//toString 
	
	public String toString() {
		return "NbOctets: " +nbOctets+ "\nAngle: " +anglePhoto+ "\nType: " 
				+type+ "\nOrdre du paquet: " +ordrePaquet+
				"\nNombre de paquets : " + nbPaquets +
				"\nNom du fichier: " +nomFichier; 
	}
	
	public void setIdUnique(String idUnique) {
		this.nomFichier = idUnique;
	}
	
	
	
}
