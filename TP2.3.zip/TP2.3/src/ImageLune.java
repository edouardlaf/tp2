/*
 * Enregistrement pour regrouper nom de fichier et angle.
 */
public class ImageLune {
	
	public double angle;
	public String nomFichier;

}
